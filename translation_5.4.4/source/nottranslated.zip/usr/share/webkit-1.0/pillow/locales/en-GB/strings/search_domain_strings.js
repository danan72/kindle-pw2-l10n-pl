100pt	
All Text	
Baidu Baike	
Baidu	
Dictionary	
Douban	
Google	
Kindle Store	
My Items	
Web Address	
Wikipedia	
