Cancel	
Close	
Connection Required	
Edit	
Lock Rotation	
Menu	
OK	
Register	
Remove	
Shop in Kindle Store	
This action requires wireless to be turned on.	
Turn Off Wireless	
Turn On Wireless	
Unable to Connect	
Unlock Rotation	
Your Kindle is currently unable to connect.<br><br>Please try again later.	
