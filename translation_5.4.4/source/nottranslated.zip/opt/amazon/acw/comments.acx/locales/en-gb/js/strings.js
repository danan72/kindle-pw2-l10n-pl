1 character over	
Aeroplane Mode must be turned off to use this feature.	
Close	
Comments	
Facebook	
Getting your settings...	
Share on Weibo	
Share on:	
Share to Goodreads	
Share your thoughts	
Share	
Shared successfully on Facebook and Twitter.	
Shared successfully on [n].	
Sharing is disabled for this title.	
Sharing	
Twitter	
Unable to Share. You have reached the clipping limit for this item.	
Unable to post. Please try again.	
Unable to retrieve your social network settings. Please try again later.	
Weibo	
You must select a social network to use the Sharing feature.	
Your message is being shared.	
[n] characters over	
