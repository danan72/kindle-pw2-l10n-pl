About ${author}	
About the Author	
About the Authors	
Full Wikipedia Article	
Kindle books by ${author}	
Other books by ${author}	
Subject to a Creative Commons Licence	
This page is currently unavailable.	
